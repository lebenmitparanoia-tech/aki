
import React from 'react';
export default function ModeToggles(){ 
  return <div style={{opacity:.8}}>Mode toggles (coming soon)</div>; 
}
