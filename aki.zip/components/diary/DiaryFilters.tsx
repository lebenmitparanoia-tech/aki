
import React from 'react';
export default function DiaryFilters(){ 
  return <div style={{opacity:.8}}>Filters (coming soon)</div>; 
}
