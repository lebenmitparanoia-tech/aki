// Type declaration for the local JS component so TS is happy.
import React from 'react';
declare const Component: React.ComponentType<any>;
export default Component;
