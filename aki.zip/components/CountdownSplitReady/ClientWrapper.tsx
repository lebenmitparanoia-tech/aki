"use client";
import React from "react";
// Re-export the existing JS component as a client component boundary
import Original from "./index.jsx";
export default Original;
