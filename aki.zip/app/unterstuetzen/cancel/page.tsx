export default function Cancel(){
  return (
    <main className="container spaced">
      <h1 className="section-title">Abgebrochen</h1>
      <p className="section-sub">Du kannst den Vorgang jederzeit erneut starten – danke fürs Reinschauen.</p>
    </main>
  )
}
