// Ambient types for the JS countdown component so TypeScript is happy.
declare module '@/components/CountdownSplitReady' {
  import React from 'react';
  const Component: React.ComponentType<any>;
  export default Component;
}
